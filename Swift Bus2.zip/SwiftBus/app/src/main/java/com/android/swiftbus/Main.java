package com.android.swiftbus;

import android.os.Bundle;
import android.view.MenuItem;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Main extends AppCompatActivity {

    Fragment fragment = new Home();
    BottomNavigationView bottom_navigation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bottom_navigation = findViewById(R.id.bottom_navigation);
        //to show default fragment
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.framecontainer, fragment)
                .commit();
        bottom_navigation.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.home){
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.framecontainer, new Home())
                        .commit();
            }
            else if (item.getItemId() == R.id.booking){
                fragment = new Booking();
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.framecontainer, fragment)
                        .commit();
            }
            else if (item.getItemId() == R.id.profile){
                fragment = new Profile();
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.framecontainer, fragment)
                        .commit();
            }
            else if (item.getItemId() == R.id.more){
                fragment = new More();
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.framecontainer, fragment)
                        .commit();
            }
            else if (item.getItemId() == R.id.traking) {
                fragment = new Tracking();
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.framecontainer, fragment)
                        .commit();
            }
            return true;
        });
    }
}