package com.android.swiftbus;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class Signup extends AppCompatActivity {

    FirebaseAuth auth;
    Button signup;
    EditText name;
    EditText email;
    EditText password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        auth = FirebaseAuth.getInstance();
        signup = findViewById(R.id.signupbutton);
        name = findViewById(R.id.name);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailText = email.getText().toString();
                String passwordText = password.getText().toString();
                String nameText = name.getText().toString();

                auth.createUserWithEmailAndPassword(emailText, passwordText).addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        startActivity(new Intent(Signup.this,Main.class));
                        Toast.makeText(Signup.this, "Account Created", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(Signup.this, task.getException() + "", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }
}
