import android.app.Activity;

public class Home extends Activity {
}
