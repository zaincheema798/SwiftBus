package com.android.swiftbus;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.SwitchCompat;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.appbar.CollapsingToolbarLayout;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class Profile extends Fragment {

    // UI Components
    private CircleImageView profileImage;
    private ImageView editProfileBtn;
    private TextView profileName, profileMembership;
    private TextView profileEmail, profilePhone, profileGender, profileAge, profileBlood, profileAddress;
    private TextView tripsCount, citiesCount, pointsCount;
    private RecyclerView upcomingTripsRecycler;
    private TextView noTripsText, viewAllTrips;
    private SwitchCompat notificationsSwitch, darkModeSwitch;
    private Button logoutButton;
    private FloatingActionButton fabScanTicket;

    // Containers that need click listeners
    private View paymentMethodsContainer, travelPreferencesContainer;
    private View notificationsContainer, darkModeContainer;
    private View accountSettingsContainer, helpSupportContainer, aboutContainer;

    // User data - in a real app, this would be fetched from a database or API
    private UserProfile userProfile;
    private List<Trip> upcomingTrips;
    private TripAdapter tripAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        // Initialize the UI components
        initializeViews(view);

        // Load mock data (in a real app, this would be fetched from a database or API)
        loadMockData();

        // Set up RecyclerView for upcoming trips
        setupUpcomingTripsRecyclerView();

        // Populate user profile data
        populateUserProfile();

        // Set up click listeners
        setupClickListeners();

        return view;
    }

    private void initializeViews(View view) {
        // Profile section
        profileImage = view.findViewById(R.id.profile_image);
        editProfileBtn = view.findViewById(R.id.edit_profile_btn);
        profileName = view.findViewById(R.id.profile_name);
        profileMembership = view.findViewById(R.id.profile_membership);

        // Personal information
        profileEmail = view.findViewById(R.id.profile_email);
        profilePhone = view.findViewById(R.id.profile_phone);
        profileGender = view.findViewById(R.id.profile_gender);
        profileAge = view.findViewById(R.id.profile_age);
        profileBlood = view.findViewById(R.id.profile_blood);
        profileAddress = view.findViewById(R.id.profile_address);

        // Stats section
        tripsCount = view.findViewById(R.id.trips_count);
        citiesCount = view.findViewById(R.id.cities_count);
        pointsCount = view.findViewById(R.id.points_count);

        // Upcoming trips section
        upcomingTripsRecycler = view.findViewById(R.id.upcoming_trips_recycler);
        noTripsText = view.findViewById(R.id.no_trips_text);
        viewAllTrips = view.findViewById(R.id.view_all_trips);

        // Preferences section
        paymentMethodsContainer = view.findViewById(R.id.payment_methods_container);
        travelPreferencesContainer = view.findViewById(R.id.travel_preferences_container);
        notificationsContainer = view.findViewById(R.id.notifications_container);
        darkModeContainer = view.findViewById(R.id.dark_mode_container);
        notificationsSwitch = view.findViewById(R.id.notifications_switch);
        darkModeSwitch = view.findViewById(R.id.dark_mode_switch);

        // Account section
        accountSettingsContainer = view.findViewById(R.id.account_settings_container);
        helpSupportContainer = view.findViewById(R.id.help_support_container);
        aboutContainer = view.findViewById(R.id.about_container);
        logoutButton = view.findViewById(R.id.logout_button);

        // FAB
        fabScanTicket = view.findViewById(R.id.fab_scan_ticket);

    }

    private void loadMockData() {
        // Create mock user profile
        userProfile = new UserProfile(
                "Zain ul abideen Cheema",
                "Premium Member",
                "Zainalicheema798@gmail.com",
                "03107898620",
                "Male",
                "21 Years old",
                "Blood Group: AB+",
                "Lahore, Pakistan",
                24,
                12,
                2450
        );

        // Create mock upcoming trips
        upcomingTrips = new ArrayList<>();
        upcomingTrips.add(new Trip("Lahore to Islamabad", "15 Mar 2025", "07:30 AM", "Daewoo Express", "Seat: A12", R.drawable.ic_bus));
        upcomingTrips.add(new Trip("Islamabad to Peshawar", "22 Mar 2025", "09:00 AM", "Faisal Movers", "Seat: B08", R.drawable.ic_bus));
    }

    private void setupUpcomingTripsRecyclerView() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        upcomingTripsRecycler.setLayoutManager(layoutManager);

        tripAdapter = new TripAdapter(upcomingTrips);
        upcomingTripsRecycler.setAdapter(tripAdapter);

        // Show/hide no trips text based on data
        if (upcomingTrips.isEmpty()) {
            noTripsText.setVisibility(View.VISIBLE);
            upcomingTripsRecycler.setVisibility(View.GONE);
        } else {
            noTripsText.setVisibility(View.GONE);
            upcomingTripsRecycler.setVisibility(View.VISIBLE);
        }
    }

    private void populateUserProfile() {
        // Set user profile data to UI
        profileName.setText(userProfile.getName());
        profileMembership.setText(userProfile.getMembershipStatus());
        profileEmail.setText(userProfile.getEmail());
        profilePhone.setText(userProfile.getPhone());
        profileGender.setText(userProfile.getGender());
        profileAge.setText(userProfile.getAge());
        profileBlood.setText(userProfile.getBloodGroup());
        profileAddress.setText(userProfile.getAddress());

        // Set stats
        tripsCount.setText(String.valueOf(userProfile.getTripsCount()));
        citiesCount.setText(String.valueOf(userProfile.getCitiesCount()));
        pointsCount.setText(String.valueOf(userProfile.getPointsCount()));
    }

    private void setupClickListeners() {
        // Edit profile button
        editProfileBtn.setOnClickListener(v -> {
            navigateToEditProfile();
        });

        // View all trips
        viewAllTrips.setOnClickListener(v -> {
            navigateToAllTrips();
        });

        // Preference section clicks
        paymentMethodsContainer.setOnClickListener(v -> {
            navigateToPaymentMethods();
        });

        travelPreferencesContainer.setOnClickListener(v -> {
            navigateToTravelPreferences();
        });

        notificationsContainer.setOnClickListener(v -> {
            notificationsSwitch.toggle();
        });

        darkModeContainer.setOnClickListener(v -> {
            darkModeSwitch.toggle();
            toggleDarkMode(darkModeSwitch.isChecked());
        });

        // Account section clicks
        accountSettingsContainer.setOnClickListener(v -> {
            navigateToAccountSettings();
        });

        helpSupportContainer.setOnClickListener(v -> {
            navigateToHelpSupport();
        });

        aboutContainer.setOnClickListener(v -> {
            navigateToAbout();
        });

        // Logout button
        logoutButton.setOnClickListener(v -> {
            logoutUser();
        });

        // FAB - Scan Ticket
        fabScanTicket.setOnClickListener(v -> {
            navigateToScanTicket();
        });

        // Switch listeners
        notificationsSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            updateNotificationSettings(isChecked);
        });

        darkModeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            toggleDarkMode(isChecked);
        });
    }

    // Navigation and action methods

    private void navigateToEditProfile() {
        Toast.makeText(getContext(), "Edit Profile clicked", Toast.LENGTH_SHORT).show();
        // In a real app, you would start a new Activity or Fragment
        // Intent intent = new Intent(getActivity(), EditProfileActivity.class);
        // startActivity(intent);
    }

    private void navigateToAllTrips() {
        Toast.makeText(getContext(), "View All Trips clicked", Toast.LENGTH_SHORT).show();
        // Navigate to all trips screen
    }

    private void navigateToPaymentMethods() {
        Toast.makeText(getContext(), "Payment Methods clicked", Toast.LENGTH_SHORT).show();
        // Navigate to payment methods screen
    }

    private void navigateToTravelPreferences() {
        Toast.makeText(getContext(), "Travel Preferences clicked", Toast.LENGTH_SHORT).show();
        // Navigate to travel preferences screen
    }

    private void updateNotificationSettings(boolean enabled) {
        Toast.makeText(getContext(), "Notifications " + (enabled ? "enabled" : "disabled"), Toast.LENGTH_SHORT).show();
        // Update notification settings in SharedPreferences or on server
    }

    private void toggleDarkMode(boolean darkMode) {
        Toast.makeText(getContext(), "Dark Mode " + (darkMode ? "enabled" : "disabled"), Toast.LENGTH_SHORT).show();
        // Implement dark mode toggle logic
        // In a real app, this would update app theme
    }

    private void navigateToAccountSettings() {
        Toast.makeText(getContext(), "Account Settings clicked", Toast.LENGTH_SHORT).show();
        // Navigate to account settings screen
    }

    private void navigateToHelpSupport() {
        Toast.makeText(getContext(), "Help & Support clicked", Toast.LENGTH_SHORT).show();
        // Navigate to help & support screen
    }

    private void navigateToAbout() {
        Toast.makeText(getContext(), "About Us clicked", Toast.LENGTH_SHORT).show();
        // Navigate to about screen
    }

    private void logoutUser() {
        // Show confirmation dialog
        // Then perform logout
        Toast.makeText(getContext(), "Logging out...", Toast.LENGTH_SHORT).show();
        // In a real app:
        // 1. Clear user session, tokens, etc.
        // 2. Navigate to login screen
        // Intent intent = new Intent(getActivity(), LoginActivity.class);
        // intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        // startActivity(intent);
    }

    private void navigateToScanTicket() {
        Toast.makeText(getContext(), "Scan Ticket clicked", Toast.LENGTH_SHORT).show();
        // Launch QR scanner
        // Intent intent = new Intent(getActivity(), ScanTicketActivity.class);
        // startActivity(intent);
    }

    // Model classes

    // UserProfile model class
    private static class UserProfile {
        private String name;
        private String membershipStatus;
        private String email;
        private String phone;
        private String gender;
        private String age;
        private String bloodGroup;
        private String address;
        private int tripsCount;
        private int citiesCount;
        private int pointsCount;

        public UserProfile(String name, String membershipStatus, String email, String phone,
                           String gender, String age, String bloodGroup, String address,
                           int tripsCount, int citiesCount, int pointsCount) {
            this.name = name;
            this.membershipStatus = membershipStatus;
            this.email = email;
            this.phone = phone;
            this.gender = gender;
            this.age = age;
            this.bloodGroup = bloodGroup;
            this.address = address;
            this.tripsCount = tripsCount;
            this.citiesCount = citiesCount;
            this.pointsCount = pointsCount;
        }

        // Getters
        public String getName() { return name; }
        public String getMembershipStatus() { return membershipStatus; }
        public String getEmail() { return email; }
        public String getPhone() { return phone; }
        public String getGender() { return gender; }
        public String getAge() { return age; }
        public String getBloodGroup() { return bloodGroup; }
        public String getAddress() { return address; }
        public int getTripsCount() { return tripsCount; }
        public int getCitiesCount() { return citiesCount; }
        public int getPointsCount() { return pointsCount; }
    }

    // Trip model class
    private static class Trip {
        private String route;
        private String date;
        private String time;
        private String busOperator;
        private String seatInfo;
        private int iconResId;

        public Trip(String route, String date, String time, String busOperator, String seatInfo, int iconResId) {
            this.route = route;
            this.date = date;
            this.time = time;
            this.busOperator = busOperator;
            this.seatInfo = seatInfo;
            this.iconResId = iconResId;
        }

        // Getters
        public String getRoute() { return route; }
        public String getDate() { return date; }
        public String getTime() { return time; }
        public String getBusOperator() { return busOperator; }
        public String getSeatInfo() { return seatInfo; }
        public int getIconResId() { return iconResId; }
    }

    // Trip adapter for RecyclerView
    private class TripAdapter extends RecyclerView.Adapter<TripAdapter.TripViewHolder> {
        private List<Trip> trips;

        public TripAdapter(List<Trip> trips) {
            this.trips = trips;
        }

        @Override
        public TripViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_upcoming_trip, parent, false);
            return new TripViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(TripViewHolder holder, int position) {
            Trip trip = trips.get(position);
            // Bind data to views - this implementation depends on your item_upcoming_trip.xml layout
            // Since we don't have the exact layout, this is a placeholder for what you would typically do

            // Example (adjust based on your actual layout):
            // holder.routeTextView.setText(trip.getRoute());
            // holder.dateTextView.setText(trip.getDate());
            // holder.timeTextView.setText(trip.getTime());
            // holder.busOperatorTextView.setText(trip.getBusOperator());
            // holder.seatInfoTextView.setText(trip.getSeatInfo());
            // holder.iconImageView.setImageResource(trip.getIconResId());

            // Set click listener for the item
            holder.itemView.setOnClickListener(v -> {
                // Navigate to trip details
                Toast.makeText(getContext(), "Trip details: " + trip.getRoute(), Toast.LENGTH_SHORT).show();
            });
        }

        @Override
        public int getItemCount() {
            return trips.size();
        }

        public class TripViewHolder extends RecyclerView.ViewHolder {
            // Declare views from item_upcoming_trip.xml
            // For example:
            // public TextView routeTextView, dateTextView, timeTextView, busOperatorTextView, seatInfoTextView;
            // public ImageView iconImageView;

            public TripViewHolder(View view) {
                super(view);
                // Initialize views
                // routeTextView = view.findViewById(R.id.trip_route);
                // dateTextView = view.findViewById(R.id.trip_date);
                // timeTextView = view.findViewById(R.id.trip_time);
                // busOperatorTextView = view.findViewById(R.id.trip_operator);
                // seatInfoTextView = view.findViewById(R.id.trip_seat);
                // iconImageView = view.findViewById(R.id.trip_icon);
            }
        }
    }
}