package com.android.swiftbus;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class Booking extends Fragment {

    // UI elements
    private Button datePickerButton;
    private TextView selectedDateText;
    private Spinner schedulesSpinner;
    private EditText specialRequests;
    private Button bookTicketButton;
    private TextView fareText;
    private TextView optionsCostText;
    private TextView taxesText;
    private TextView totalFareText;
    private Spinner sourceSpinner;
    private Spinner destSpinner;
    private TextView ticketConditionsText; // New TextView for ticket conditions

    // Checkboxes
    private CheckBox blanketSeatCheck;
    private CheckBox windowSeatCheck;
    private CheckBox mealOnRideCheck;
    private CheckBox luggageCheck;
    private CheckBox wifiCheck;
    private CheckBox powerOutletCheck;

    // Pricing variables
    private int baseFare = 2500; // Default value, will be replaced by route price
    private int optionsCost = 0;
    private final int taxRate = 10; // 10% tax
    private int totalFare = 0;

    // Selected values
    private String selectedTicketType = "";
    private int selectedPassengers = 1;
    private String selectedTripType = "";
    private String selectedSource = "";
    private String selectedDestination = "";
    private String selectedSeatType = "";
    private Date selectedDate = null;
    private String selectedSchedule = "";

    // Additional costs for options
    private final Map<String, Integer> optionPrices = new HashMap<String, Integer>() {{
        put("blanketSeat", 150);
        put("windowSeat", 200);
        put("mealOnRide", 350);
        put("luggage", 250);
        put("wifi", 100);
        put("powerOutlet", 50);
    }};

    // Ticket type discounts (percentage)
    private final Map<String, Integer> ticketDiscounts = new HashMap<String, Integer>() {{
        put("Regular", 0);    // No discount
        put("VIP", -30);      // 30% premium (negative discount)
        put("Student", 20);   // 20% discount
        put("Senior", 15);    // 15% discount
    }};

    // Ticket type conditions
    private final Map<String, String> ticketConditions = new HashMap<String, String>() {{
        put("Regular", "Standard fare with no special requirements.");
        put("VIP", "VIP passengers receive priority boarding and premium services.");
        put("Student", "The passenger must carry his/her student identity card to prove this claim.");
        put("Senior", "Senior citizens must be 60 years or older and carry valid ID proof.");
    }};

    private RecentRoute route;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_booking, container, false);

        // Check if we have a route from arguments
        if (getArguments() != null) {
            route = (RecentRoute) getArguments().getSerializable("route");
            if (route != null) {
                // Use route price as base fare
                baseFare = Integer.parseInt(route.getPrice());
            }
        }

        // Initialize UI elements
        initializeUI(view);

        // Setup spinners
        setupTicketTypeSpinner(view);
        setupPassengersSpinner(view);
        setupTripTypeSpinner(view);
        setupLocationSpinners(view);
        setupSeatTypeSpinner(view);
        setupSchedulesSpinner(view);

        // Setup date picker
        setupDatePicker(view);

        // Setup checkboxes
        setupCheckboxes(view);

        // Setup special requests
        setupSpecialRequests(view);

        // Setup fare display
        updateFareDisplay();

        // Setup book ticket button
        setupBookButton(view);

        // Initialize schedules based on route or default
        initializeSchedules();

        return view;
    }

    private void initializeUI(View view) {
        // Initialize text views
        fareText = view.findViewById(R.id.text_fare);
        optionsCostText = view.findViewById(R.id.text_options_cost);
        taxesText = view.findViewById(R.id.text_taxes);
        totalFareText = view.findViewById(R.id.text_total_fare);
        ticketConditionsText = view.findViewById(R.id.text_message); // Initialize new TextView

        // Initialize date picker
        datePickerButton = view.findViewById(R.id.button_pick_date);
        selectedDateText = view.findViewById(R.id.text_selected_date);

        // Initialize special requests
        specialRequests = view.findViewById(R.id.edit_special_requests);

        // Initialize checkboxes
        blanketSeatCheck = view.findViewById(R.id.checkbox_blanket_seat);
        windowSeatCheck = view.findViewById(R.id.checkbox_window_seat);
        mealOnRideCheck = view.findViewById(R.id.checkbox_meal_on_ride);
        luggageCheck = view.findViewById(R.id.checkbox_luggage);
        wifiCheck = view.findViewById(R.id.checkbox_wifi);
        powerOutletCheck = view.findViewById(R.id.checkbox_power_outlet);

        // Initialize book button
        bookTicketButton = view.findViewById(R.id.button_book_ticket);

        // Initialize spinners
        sourceSpinner = view.findViewById(R.id.spinner_source);
        destSpinner = view.findViewById(R.id.spinner_destination);
        schedulesSpinner = view.findViewById(R.id.spinner_schedules);
    }

    private void initializeSchedules() {
        // This method ensures schedules are initialized after all UI components are set up
        if (route != null) {
            // If we have a route, update schedules based on it
            updateAvailableSchedules();
        } else {
            // Otherwise, set default adapter
            List<String> defaultItems = Arrays.asList("Select a source and destination first");
            ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(),
                    android.R.layout.simple_spinner_item, defaultItems);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            schedulesSpinner.setAdapter(adapter);
        }
    }

    private void setupTicketTypeSpinner(View view) {
        Spinner spinner = view.findViewById(R.id.spinner_ticket_type);
        List<String> items = Arrays.asList("Select Ticket Type", "Regular", "VIP", "Student", "Senior");
        setupSpinner(view, R.id.spinner_ticket_type, items);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    selectedTicketType = (String) parent.getItemAtPosition(position);

                    // Update the conditions text based on selected ticket type
                    if (ticketConditions.containsKey(selectedTicketType)) {
                        ticketConditionsText.setText(ticketConditions.get(selectedTicketType));
                        ticketConditionsText.setVisibility(View.VISIBLE);
                    } else {
                        ticketConditionsText.setVisibility(View.GONE);
                    }

                    updateFareDisplay();
                } else {
                    // Hide conditions if "Select Ticket Type" is chosen
                    ticketConditionsText.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });
    }

    private void setupPassengersSpinner(View view) {
        Spinner spinner = view.findViewById(R.id.spinner_no_of_passengers);
        List<String> items = Arrays.asList("Select", "1", "2", "3", "4", "5");
        setupSpinner(view, R.id.spinner_no_of_passengers, items);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    selectedPassengers = Integer.parseInt((String) parent.getItemAtPosition(position));
                    updateFareDisplay();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });
    }

    private void setupTripTypeSpinner(View view) {
        Spinner spinner = view.findViewById(R.id.spinner_trip_type);
        List<String> items = Arrays.asList("Select Trip Type", "One Way", "Round Trip");
        setupSpinner(view, R.id.spinner_trip_type, items);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    selectedTripType = (String) parent.getItemAtPosition(position);
                    updateFareDisplay();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });
    }

    private void setupLocationSpinners(View view) {
        List<String> sources;
        List<String> destinations;

        if (route != null) {
            // If we have a route, use its source/destination
            sources = Arrays.asList(route.getSource());
            destinations = Arrays.asList(route.getDestination());
            selectedSource = route.getSource();
            selectedDestination = route.getDestination();

            // Make spinners non-editable when route is provided
            sourceSpinner.setEnabled(false);
            destSpinner.setEnabled(false);
        } else {
            // Otherwise use default lists
            sources = Arrays.asList("Select Source", "Karachi", "Lahore", "Islamabad");
            destinations = Arrays.asList("Select Destination", "Karachi", "Lahore", "Islamabad");
        }

        // Setup spinners with appropriate data
        ArrayAdapter<String> sourceAdapter = new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_spinner_item, sources);
        sourceAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sourceSpinner.setAdapter(sourceAdapter);

        ArrayAdapter<String> destAdapter = new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_spinner_item, destinations);
        destAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        destSpinner.setAdapter(destAdapter);

        sourceSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0 || route != null) {
                    selectedSource = (String) parent.getItemAtPosition(position);
                    updateAvailableSchedules();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });

        destSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0 || route != null) {
                    selectedDestination = (String) parent.getItemAtPosition(position);
                    updateAvailableSchedules();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });
    }

    private void setupSeatTypeSpinner(View view) {
        Spinner spinner = view.findViewById(R.id.spinner_seat_type);
        List<String> items = Arrays.asList("Select Seat Type", "Sleeper", "AC", "Economy", "Premium");
        setupSpinner(view, R.id.spinner_seat_type, items);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    selectedSeatType = (String) parent.getItemAtPosition(position);
                    updateFareDisplay();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });
    }

    private void setupSchedulesSpinner(View view) {
        schedulesSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0 && !parent.getItemAtPosition(position).equals("Select a source and destination first")) {
                    selectedSchedule = (String) parent.getItemAtPosition(position);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });
    }

    private void updateAvailableSchedules() {
        // Safety check for spinner
        if (schedulesSpinner == null) {
            return;
        }

        // Determine if we have valid source and destination
        boolean hasValidSource = !selectedSource.isEmpty() && !selectedSource.startsWith("Select");
        boolean hasValidDestination = !selectedDestination.isEmpty() && !selectedDestination.startsWith("Select");

        // If we have a route, we always have valid source/destination
        if (route != null) {
            hasValidSource = true;
            hasValidDestination = true;
        }

        if (!hasValidSource || !hasValidDestination) {
            // No valid source/destination, show default message
            List<String> defaultItems = Arrays.asList("Select a source and destination first");
            ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(),
                    android.R.layout.simple_spinner_item, defaultItems);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            schedulesSpinner.setAdapter(adapter);
            return;
        }

        // Both source and destination are valid, show schedules
        List<String> schedules = Arrays.asList(
                "Select Schedule",
                "Morning (6:00 AM - " + selectedSource + " to " + selectedDestination + ")",
                "Afternoon (12:00 PM - " + selectedSource + " to " + selectedDestination + ")",
                "Evening (6:00 PM - " + selectedSource + " to " + selectedDestination + ")",
                "Night (10:00 PM - " + selectedSource + " to " + selectedDestination + ")"
        );

        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_spinner_item, schedules);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        schedulesSpinner.setAdapter(adapter);
    }

    private void setupDatePicker(View view) {
        datePickerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog();
            }
        });
    }

    private void showDatePickerDialog() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                requireContext(),
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        calendar.set(year, month, dayOfMonth);
                        selectedDate = calendar.getTime();

                        SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());
                        String formattedDate = dateFormat.format(selectedDate);
                        selectedDateText.setText(formattedDate);
                    }
                },
                year, month, day
        );

        // Set minimum date to today
        datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
        datePickerDialog.show();
    }

    private void setupCheckboxes(View view) {
        CompoundButton.OnCheckedChangeListener checkListener = new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                updateOptionsCost();
            }
        };

        blanketSeatCheck.setOnCheckedChangeListener(checkListener);
        windowSeatCheck.setOnCheckedChangeListener(checkListener);
        mealOnRideCheck.setOnCheckedChangeListener(checkListener);
        luggageCheck.setOnCheckedChangeListener(checkListener);
        wifiCheck.setOnCheckedChangeListener(checkListener);
        powerOutletCheck.setOnCheckedChangeListener(checkListener);
    }

    private void updateOptionsCost() {
        optionsCost = 0;

        if (blanketSeatCheck.isChecked()) {
            optionsCost += optionPrices.get("blanketSeat");
        }

        if (windowSeatCheck.isChecked()) {
            optionsCost += optionPrices.get("windowSeat");
        }

        if (mealOnRideCheck.isChecked()) {
            optionsCost += optionPrices.get("mealOnRide");
        }

        if (luggageCheck.isChecked()) {
            optionsCost += optionPrices.get("luggage");
        }

        if (wifiCheck.isChecked()) {
            optionsCost += optionPrices.get("wifi");
        }

        if (powerOutletCheck.isChecked()) {
            optionsCost += optionPrices.get("powerOutlet");
        }

        updateFareDisplay();
    }

    private void setupSpecialRequests(View view) {
        specialRequests.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Do nothing
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Do nothing
            }

            @Override
            public void afterTextChanged(Editable s) {
                // Could add custom validation or processing here
            }
        });
    }

    private void updateFareDisplay() {
        // Get the route's price as the base fare if available
        if (route != null) {
            baseFare = Integer.parseInt(route.getPrice());
        }

        int adjustedBaseFare = baseFare;

        // Apply ticket type discount if available
        if (!selectedTicketType.isEmpty() && ticketDiscounts.containsKey(selectedTicketType)) {
            int discountPercent = ticketDiscounts.get(selectedTicketType);
            // Negative discount = premium, positive = discount
            adjustedBaseFare = adjustedBaseFare - (adjustedBaseFare * discountPercent / 100);
        }

        // Apply seat type adjustments
        if (selectedSeatType.equals("Sleeper")) {
            adjustedBaseFare += (int)(baseFare * 0.2); // 20% extra
        } else if (selectedSeatType.equals("AC")) {
            adjustedBaseFare += (int)(baseFare * 0.15); // 15% extra
        } else if (selectedSeatType.equals("Premium")) {
            adjustedBaseFare += (int)(baseFare * 0.3); // 30% extra
        }

        // Apply round trip discount
        if (selectedTripType.equals("Round Trip")) {
            adjustedBaseFare = (int)(adjustedBaseFare * 1.85); // 15% discount on second ticket
        }

        // Multiply by number of passengers
        int totalBaseFare = adjustedBaseFare * selectedPassengers;

        // Calculate taxes
        int taxAmount = (int)((totalBaseFare + optionsCost) * (taxRate / 100.0));

        // Calculate total fare
        totalFare = totalBaseFare + optionsCost + taxAmount;

        // Update the UI
        fareText.setText("Fare: " + totalBaseFare);
        optionsCostText.setText("Additional Options: " + optionsCost);
        taxesText.setText("Taxes & Fees: " + taxAmount);
        totalFareText.setText("Total Fare: " + totalFare);
    }

    private void setupBookButton(View view) {
        bookTicketButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateBooking()) {
                    // Perform booking action
                    // Here you would typically send the booking data to your backend
                    Intent intent = new Intent(getContext(), BookingConfirmationActivity.class);
                    intent.putExtra("bookingNumber", "123456789");
                    intent.putExtra("busNumber", 123);
                    intent.putExtra("fare", totalFare);
                    startActivity(intent);
                }
            }
        });
    }

    private boolean validateBooking() {
        // Validate all required fields are selected
        if (selectedTicketType.isEmpty() || selectedTicketType.startsWith("Select")) {
            showError("Please select a ticket type");
            return false;
        }

        if (selectedSource.isEmpty() || selectedSource.startsWith("Select")) {
            showError("Please select a source location");
            return false;
        }

        if (selectedDestination.isEmpty() || selectedDestination.startsWith("Select")) {
            showError("Please select a destination");
            return false;
        }

        if (selectedSeatType.isEmpty() || selectedSeatType.startsWith("Select")) {
            showError("Please select a seat type");
            return false;
        }

        if (selectedTripType.isEmpty() || selectedTripType.startsWith("Select")) {
            showError("Please select a trip type");
            return false;
        }

        if (selectedDate == null) {
            showError("Please select a travel date");
            return false;
        }

        if (selectedSchedule.isEmpty() || selectedSchedule.startsWith("Select")) {
            showError("Please select a schedule");
            return false;
        }

        return true;
    }

    private void showError(String message) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
    }

    private void setupSpinner(View view, int spinnerId, List<String> items) {
        Spinner spinner = view.findViewById(spinnerId);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, items);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }
}