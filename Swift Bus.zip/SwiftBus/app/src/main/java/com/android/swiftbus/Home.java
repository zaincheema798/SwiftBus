package com.android.swiftbus;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.util.Log;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;

public class Home extends Fragment {

    private static final String TAG = "HomeFragment";

    private RecyclerView recyclerQuick, recyclerRecent;
    private List<QuickAccess> quickAccessList;
    private QuickAccessAdapter quickAccessAdapter;

    private List<RecentRoute> recentRouteList;
    private RecentRouteAdapter recentRouteAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // 1. Quick Access RecyclerView
        recyclerQuick = view.findViewById(R.id.recycler_quick);
        recyclerQuick.setLayoutManager(
                new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false)
        );

        quickAccessList = new ArrayList<>();
        quickAccessList.add(new QuickAccess("Book a Ticket", R.drawable.ic_booking_q));
        quickAccessList.add(new QuickAccess("My Bookings", R.drawable.ic_booking_q));
        quickAccessList.add(new QuickAccess("Offers & Discounts", R.drawable.ic_booking_q));
        quickAccessList.add(new QuickAccess("Travel History", R.drawable.ic_booking_q));
        quickAccessList.add(new QuickAccess("Help & Support", R.drawable.ic_booking_q));

        quickAccessAdapter = new QuickAccessAdapter(getContext(), quickAccessList);
        recyclerQuick.setAdapter(quickAccessAdapter);

        // 2. Recent Route RecyclerView
        recyclerRecent = view.findViewById(R.id.recent_route);
        recyclerRecent.setLayoutManager(
                new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false)
        );

        recentRouteList = new ArrayList<>();
        recentRouteAdapter = new RecentRouteAdapter(getContext(), recentRouteList);
        recyclerRecent.setAdapter(recentRouteAdapter);

        // 3. Load data from Firestore
        loadRoutesFromFirestore();

        return view;
    }

    /**
     * Fetches documents from the "Route" collection in Firestore
     * and updates the RecentRouteAdapter.
     */
    private void loadRoutesFromFirestore() {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("Route") // Firestore collection name
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    recentRouteList.clear();
                    for (DocumentSnapshot doc : queryDocumentSnapshots) {
                        // Convert each document into a RecentRoute object.
                        // Make sure Firestore fields match RecentRoute fields (title, image)
                        RecentRoute route = doc.toObject(RecentRoute.class);
                        if (route != null) {
                            recentRouteList.add(route);
                            Log.d(TAG, "Loaded route: " + route.getTitle() + ", " + route.getImage());
                        }
                    }
                    // Notify the adapter to refresh the RecyclerView
                    recentRouteAdapter.notifyDataSetChanged();
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error loading routes from Firestore", e);
                });
    }
}
