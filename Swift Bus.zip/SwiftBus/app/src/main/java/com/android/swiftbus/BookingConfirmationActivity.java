package com.android.swiftbus;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class BookingConfirmationActivity extends AppCompatActivity {

    private TextView textBookingNumber;
    private TextView   textBusNumber;
    private TextView    textFare;
    private Button buttonPayWithEasypaisa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_confirmation);

        // Initialize UI elements
        textBookingNumber = findViewById(R.id.text_booking_number);
        textBusNumber = findViewById(R.id.text_bus_number);
        textFare = findViewById(R.id.text_fare);
        buttonPayWithEasypaisa = findViewById(R.id.button_pay_easypaisa);

        // Retrieve Data from Intent
        Intent intent = getIntent();
        String bookingNumber = intent.getStringExtra("bookingNumber");
        int busNumber = intent.getIntExtra("busNumber", 0);
        int fare = intent.getIntExtra("fare", 0);

        // Set Data in TextViews
        textBookingNumber.setText("Booking Number: " + bookingNumber);
        textBusNumber.setText("Bus Number: " + busNumber);
        textFare.setText("Total Fare: " + fare + " PKR");

        // Easypaisa Payment Button Click Event
        buttonPayWithEasypaisa.setOnClickListener(v -> {
            Toast.makeText(this, "Redirecting to Easypaisa Payment...", Toast.LENGTH_SHORT).show();
            // Here, you can add Easypaisa API integration logic
        });
    }
}
