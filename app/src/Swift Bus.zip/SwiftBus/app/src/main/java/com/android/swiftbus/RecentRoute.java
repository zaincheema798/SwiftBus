package com.android.swiftbus;

public class RecentRoute {
    String title;
    String image;
    public RecentRoute() {
    }
    public RecentRoute(String title, String image) {
        this.title = title;
        this.image = image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImage() {
        return image;
    }
    public String getTitle() {
        return title;
    }
}
